# Kompilacja i uruchomienie
## Utwórz katalog build i wejdź do niego
mkdir -p build
cd build
## Wygeneruj pliki builda (dla Make)
cmake ..
## Kompiluj projekt
make
## Uruchomienie (w folderze build)
/.zad1